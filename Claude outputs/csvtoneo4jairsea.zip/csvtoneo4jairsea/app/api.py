"""HTTP API.

    uvicorn app.api:app --reload

Endpoints
    GET  /api/health
    GET  /api/airports                 ?search=&country=&limit=&offset=
    GET  /api/airports/{code}          IATA or ICAO
    GET  /api/airports/{code}/routes   direct departures
    GET  /api/air/route                ?from=&to=&optimize=distance|stops&max_stops=&avoid=
    POST /api/air/routes               JSON {from, to, k, optimize, max_stops, avoid}
    POST /api/air/reload               drop the cached route graph (after re-loading CSVs)
    GET  /air_routing.html             route-finder page (also at /)
"""
from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Annotated, Literal

from fastapi import FastAPI, HTTPException, Path, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from pydantic import BaseModel, Field

from .config import ROOT, settings
from .repo import AirRepository, CsvRepo, Neo4jRepo
from .service import MAX_CORRIDORS, AirportNotFound, air_corridors, air_route, resolve_iata

repo: AirRepository


def make_repo() -> AirRepository:
    if settings.backend == "csv":
        return CsvRepo(settings.airports_csv, settings.air_routes_csv)
    return Neo4jRepo(settings.neo4j_uri, settings.neo4j_user, settings.neo4j_password,
                     settings.neo4j_database, settings.graph_cache_seconds)


@asynccontextmanager
async def lifespan(_: FastAPI):
    global repo
    repo = make_repo()
    try:
        yield
    finally:
        repo.close()


app = FastAPI(title="csvtoneo4jairsea API", version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",")],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

Code = Annotated[str, Path(min_length=3, max_length=4, pattern=r"^[A-Za-z0-9]{3,4}$",
                           description="IATA (3) or ICAO (4) code")]


def _not_found(e: AirportNotFound):
    raise HTTPException(status_code=404, detail=str(e))


@app.get("/api/health")
def health():
    try:
        repo.ping()
    except Exception as e:  # surface connection problems clearly
        raise HTTPException(status_code=503, detail=f"database unavailable: {e}")
    return {"status": "ok", "backend": settings.backend}


@app.get("/api/airports")
def list_airports(
    search: str | None = Query(None, min_length=1, max_length=100,
                               description="matches IATA/ICAO exactly, or name/city substring"),
    country: str | None = Query(None, max_length=100),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
):
    total, items = repo.list_airports(search, country, limit, offset)
    return {"total": total, "limit": limit, "offset": offset, "items": items}


@app.get("/api/airports/{code}")
def get_airport(code: Code):
    airport = repo.get_airport(code)
    if airport is None:
        raise HTTPException(status_code=404, detail=f"Unknown airport code '{code}'")
    return airport


@app.get("/api/airports/{code}/routes")
def airport_routes(code: Code):
    try:
        iata = resolve_iata(repo, code)
    except AirportNotFound as e:
        _not_found(e)
    items = repo.departures(iata)
    return {"from": iata, "total": len(items), "items": items}


@app.get("/api/air/route")
def get_air_route(
    origin: str = Query(..., alias="from", min_length=3, max_length=4),
    dest: str = Query(..., alias="to", min_length=3, max_length=4),
    optimize: Literal["distance", "stops"] = Query("distance"),
    max_stops: int = Query(2, ge=0, le=settings.max_stops_limit),
    avoid: str | None = Query(None, description="comma-separated airport codes not to connect through"),
):
    if origin.strip().upper() == dest.strip().upper():
        raise HTTPException(status_code=400, detail="'from' and 'to' must differ")
    try:
        return air_route(repo, origin, dest, optimize=optimize, max_stops=max_stops,
                         avoid=avoid.split(",") if avoid else None)
    except AirportNotFound as e:
        _not_found(e)


class CorridorRequest(BaseModel):
    origin: str = Field(..., alias="from", min_length=3, max_length=4)
    dest: str = Field(..., alias="to", min_length=3, max_length=4)
    k: int = Field(3, ge=1, le=MAX_CORRIDORS)
    optimize: Literal["distance", "stops"] = "distance"
    max_stops: int = Field(3, ge=0, le=settings.max_stops_limit)
    avoid: list[str] = []


@app.post("/api/air/routes")
def get_air_corridors(req: CorridorRequest):
    """Up to k corridors that share no connecting airport, best first."""
    if req.origin.strip().upper() == req.dest.strip().upper():
        raise HTTPException(status_code=400, detail="'from' and 'to' must differ")
    try:
        return air_corridors(repo, req.origin, req.dest, k=req.k, optimize=req.optimize,
                             max_stops=req.max_stops, avoid=req.avoid)
    except AirportNotFound as e:
        _not_found(e)


@app.post("/api/air/reload")
def reload_graph():
    cache = getattr(repo, "cache", None)
    if cache is not None:
        cache.clear()
    graph = repo.route_graph()
    return {"airports_with_departures": len(graph.adj), "routes": graph.edge_count}


PAGE = ROOT / "static" / "air_routing.html"


@app.get("/", include_in_schema=False)
def index():
    return RedirectResponse("/air_routing.html")


@app.get("/air_routing.html", include_in_schema=False)
def air_routing_page():
    return FileResponse(PAGE, media_type="text/html")
