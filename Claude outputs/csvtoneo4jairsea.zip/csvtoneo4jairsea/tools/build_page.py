"""Embed the bundled sample data into static/air_routing.html.

    python tools/build_page.py

The page uses the live API when it can reach it and falls back to this data.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app.csv_io import read_airports, read_routes  # noqa: E402

airports, _ = read_airports(ROOT / "data" / "airports.csv")
routes, _ = read_routes(ROOT / "data" / "air_routes.csv", airports)
data = {"airports": [a.to_dict() for a in airports], "routes": [r.to_dict() for r in routes]}
blob = json.dumps(data, separators=(",", ":")).replace("</", "<\\/")
tpl = (ROOT / "static" / "air_routing.template.html").read_text(encoding="utf-8")
out = ROOT / "static" / "air_routing.html"
out.write_text(tpl.replace("__DEMO_DATA__", blob), encoding="utf-8")
print(f"wrote {out.relative_to(ROOT)} ({len(airports)} airports, {len(routes)} routes)")
