"""Route search over an in-memory copy of the air-route graph.

Neo4j's built-in ``shortestPath`` only minimises hop count, and weighted
search needs the APOC or GDS plugins. To keep the API working on a plain
Neo4j install, the edge list is pulled once (and cached) and searched here
with a hop-limited Dijkstra. ~70k routes fit in a few MB and a search takes
milliseconds.
"""
from __future__ import annotations

import heapq
from dataclasses import dataclass
from typing import Iterable, Literal

Optimize = Literal["distance", "stops"]


@dataclass(frozen=True)
class Edge:
    source: str
    dest: str
    distance_km: float
    airlines: tuple[str, ...] = ()


class RouteGraph:
    def __init__(self, edges: Iterable[Edge]):
        self.adj: dict[str, list[Edge]] = {}
        self.edge_count = 0
        for e in edges:
            self.adj.setdefault(e.source, []).append(e)
            self.edge_count += 1

    def has_departures(self, code: str) -> bool:
        return code in self.adj

    def shortest(
        self,
        origin: str,
        dest: str,
        optimize: Optimize = "distance",
        max_stops: int = 3,
        avoid: frozenset[str] = frozenset(),
        banned_edges: frozenset[tuple[str, str]] = frozenset(),
    ) -> list[Edge] | None:
        """Best path from ``origin`` to ``dest`` with at most ``max_stops``
        intermediate airports, or ``None`` if there is none.

        ``optimize="distance"`` minimises total km; ``"stops"`` minimises the
        number of legs and breaks ties on km. ``avoid`` lists airports that
        must not be used as connections; ``banned_edges`` lists (source, dest)
        legs that must not be flown.
        """
        if origin == dest:
            return []
        max_legs = max_stops + 1

        def cost_of(km: float, legs: int) -> tuple:
            return (km, legs) if optimize == "distance" else (legs, km)

        # search state = (airport, legs used to reach it)
        best: dict[tuple[str, int], tuple] = {(origin, 0): cost_of(0.0, 0)}
        parent: dict[tuple[str, int], tuple[tuple[str, int], Edge]] = {}
        heap: list = [(cost_of(0.0, 0), 0.0, 0, origin)]
        # fewest legs with which each airport has been settled. States pop in
        # cost order, so a later state for the same airport is only worth
        # expanding if it used fewer legs (more budget left).
        settled: dict[str, int] = {}

        while heap:
            cost, km, legs, node = heapq.heappop(heap)
            if cost != best.get((node, legs)):
                continue  # stale heap entry
            if node in settled and settled[node] <= legs:
                continue
            settled[node] = legs
            if node == dest:
                path: list[Edge] = []
                key = (node, legs)
                while key in parent:
                    key, edge = parent[key]
                    path.append(edge)
                return path[::-1]
            if legs == max_legs:
                continue
            for e in self.adj.get(node, ()):
                nxt = e.dest
                if nxt != dest and nxt in avoid:
                    continue
                if banned_edges and (node, nxt) in banned_edges:
                    continue
                if nxt in settled and settled[nxt] <= legs + 1:
                    continue
                key = (nxt, legs + 1)
                nkm = km + e.distance_km
                ncost = cost_of(nkm, legs + 1)
                if key not in best or ncost < best[key]:
                    best[key] = ncost
                    parent[key] = ((node, legs), e)
                    heapq.heappush(heap, (ncost, nkm, legs + 1, nxt))
        return None
