"""Load airports and air routes from CSV into Neo4j.

    python load_air.py                       # uses AIRPORTS_CSV / AIR_ROUTES_CSV from .env
    python load_air.py data/airports.dat data/routes.dat --replace-routes
    python load_air.py --dry-run             # parse and report only, no database

Graph model
    (:Airport {iata, icao, name, city, country, latitude, longitude,
               altitude_ft, timezone, location: point})
    (:Airport)-[:AIR_ROUTE {distance_km, airlines: [..]}]->(:Airport)

One AIR_ROUTE per directed airport pair; every airline flying it is in
``airlines``. Re-running is safe (MERGE); --replace-routes first removes
existing AIR_ROUTE relationships so deleted routes disappear too.
"""
from __future__ import annotations

import argparse
import sys
import time

from app.config import settings
from app.csv_io import read_airports, read_routes

BATCH = 5000

SCHEMA = [
    "CREATE CONSTRAINT airport_iata IF NOT EXISTS FOR (a:Airport) REQUIRE a.iata IS UNIQUE",
    "CREATE INDEX airport_icao IF NOT EXISTS FOR (a:Airport) ON (a.icao)",
    "CREATE INDEX airport_country IF NOT EXISTS FOR (a:Airport) ON (a.country)",
    "CREATE POINT INDEX airport_location IF NOT EXISTS FOR (a:Airport) ON (a.location)",
]

UPSERT_AIRPORTS = """
UNWIND $rows AS row
MERGE (a:Airport {iata: row.iata})
SET a.icao = row.icao, a.name = row.name, a.city = row.city,
    a.country = row.country, a.latitude = row.latitude,
    a.longitude = row.longitude, a.altitude_ft = row.altitude_ft,
    a.timezone = row.timezone,
    a.location = point({latitude: row.latitude, longitude: row.longitude})
"""

UPSERT_ROUTES = """
UNWIND $rows AS row
MATCH (s:Airport {iata: row.source})
MATCH (d:Airport {iata: row.dest})
MERGE (s)-[r:AIR_ROUTE]->(d)
SET r.distance_km = row.distance_km, r.airlines = row.airlines
"""

DELETE_ROUTES = """
MATCH ()-[r:AIR_ROUTE]->()
CALL (r) { DELETE r } IN TRANSACTIONS OF 10000 ROWS
"""
# Neo4j < 5.23 uses the older subquery syntax
DELETE_ROUTES_LEGACY = """
MATCH ()-[r:AIR_ROUTE]->()
CALL { WITH r DELETE r } IN TRANSACTIONS OF 10000 ROWS
"""


def batches(items, size=BATCH):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("airports", nargs="?", default=settings.airports_csv)
    p.add_argument("routes", nargs="?", default=settings.air_routes_csv)
    p.add_argument("--replace-routes", action="store_true",
                   help="delete existing AIR_ROUTE relationships before loading")
    p.add_argument("--dry-run", action="store_true", help="parse only, don't touch Neo4j")
    args = p.parse_args(argv)

    t0 = time.perf_counter()
    airports, w1 = read_airports(args.airports)
    routes, w2 = read_routes(args.routes, airports)
    for w in (w1 + w2)[:20]:
        print("warning:", w)
    if len(w1 + w2) > 20:
        print(f"... and {len(w1 + w2) - 20} more warnings")
    print(f"parsed {len(airports)} airports, {len(routes)} directed routes "
          f"in {time.perf_counter() - t0:.1f}s")
    if not airports:
        print("no airports parsed - check the file and its columns", file=sys.stderr)
        return 1
    if args.dry_run:
        return 0

    from neo4j import GraphDatabase
    from neo4j.exceptions import CypherSyntaxError

    with GraphDatabase.driver(settings.neo4j_uri,
                              auth=(settings.neo4j_user, settings.neo4j_password)) as driver:
        driver.verify_connectivity()
        db = settings.neo4j_database
        for q in SCHEMA:
            driver.execute_query(q, database_=db)

        if args.replace_routes:
            with driver.session(database=db) as s:
                try:
                    s.run(DELETE_ROUTES).consume()
                except CypherSyntaxError:
                    s.run(DELETE_ROUTES_LEGACY).consume()
            print("removed existing AIR_ROUTE relationships")

        rows = [a.to_dict() for a in airports]
        for b in batches(rows):
            driver.execute_query(UPSERT_AIRPORTS, rows=b, database_=db)
        print(f"upserted {len(rows)} airports")

        rows = [r.to_dict() for r in routes]
        for i, b in enumerate(batches(rows), 1):
            driver.execute_query(UPSERT_ROUTES, rows=b, database_=db)
            print(f"  routes {min(i * BATCH, len(rows))}/{len(rows)}", end="\r")
        print(f"upserted {len(rows)} routes            ")

    print(f"done in {time.perf_counter() - t0:.1f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
