"""Read airport and air-route CSV files.

Two layouts are accepted for each file:

* A CSV with a header row. Column names are matched loosely
  (``iata`` / ``IATA`` / ``iata_code`` / ``code`` ..., ``lat`` / ``latitude`` ...).
* The OpenFlights ``airports.dat`` / ``routes.dat`` layout (no header,
  ``\\N`` for missing values).
"""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from .geo import haversine_km

NULLS = {"", "\\N", "null", "NULL", "None", "nan", "NaN", "-"}

# canonical field -> accepted header spellings (lower-cased, spaces/dashes -> _)
AIRPORT_ALIASES = {
    "iata": ["iata", "iata_code", "code", "airport_code", "iata_id"],
    "icao": ["icao", "icao_code", "gps_code", "ident"],
    "name": ["name", "airport", "airport_name"],
    "city": ["city", "municipality", "town"],
    "country": ["country", "country_name", "iso_country", "country_code"],
    "latitude": ["latitude", "lat", "latitude_deg", "y"],
    "longitude": ["longitude", "lon", "lng", "long", "longitude_deg", "x"],
    "altitude_ft": ["altitude", "altitude_ft", "elevation", "elevation_ft"],
    "timezone": ["tz", "tz_database_time_zone", "timezone", "tzdb"],
}

ROUTE_ALIASES = {
    "source": ["source", "src", "from", "origin", "source_airport", "source_iata",
               "departure", "dep", "src_iata", "from_iata"],
    "dest": ["dest", "destination", "dst", "to", "destination_airport",
             "dest_iata", "arrival", "arr", "dst_iata", "to_iata"],
    "airline": ["airline", "carrier", "airline_code", "airline_iata"],
    "stops": ["stops"],
    "distance_km": ["distance_km", "distance", "km"],
}

# OpenFlights positional layouts
OPENFLIGHTS_AIRPORT_COLS = {
    "name": 1, "city": 2, "country": 3, "iata": 4, "icao": 5,
    "latitude": 6, "longitude": 7, "altitude_ft": 8, "timezone": 11,
}
OPENFLIGHTS_ROUTE_COLS = {"airline": 0, "source": 2, "dest": 4, "stops": 7}


@dataclass
class Airport:
    iata: str
    name: str
    city: str | None
    country: str | None
    latitude: float
    longitude: float
    icao: str | None = None
    altitude_ft: float | None = None
    timezone: str | None = None

    def to_dict(self) -> dict:
        return {
            "iata": self.iata, "icao": self.icao, "name": self.name,
            "city": self.city, "country": self.country,
            "latitude": self.latitude, "longitude": self.longitude,
            "altitude_ft": self.altitude_ft, "timezone": self.timezone,
        }


@dataclass
class AirRoute:
    source: str
    dest: str
    distance_km: float
    airlines: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"source": self.source, "dest": self.dest,
                "distance_km": self.distance_km, "airlines": self.airlines}


def _norm(h: str) -> str:
    return h.strip().lstrip("﻿").lower().replace(" ", "_").replace("-", "_")


def _clean(v: str | None) -> str | None:
    if v is None:
        return None
    v = v.strip()
    return None if v in NULLS else v


def _float(v: str | None) -> float | None:
    v = _clean(v)
    if v is None:
        return None
    try:
        return float(v)
    except ValueError:
        return None


def _map_header(header: list[str], aliases: dict[str, list[str]]) -> dict[str, int]:
    normed = [_norm(h) for h in header]
    mapping: dict[str, int] = {}
    for canon, names in aliases.items():
        for n in names:
            if n in normed:
                mapping[canon] = normed.index(n)
                break
    return mapping


def _read_rows(path: Path) -> list[list[str]]:
    with open(path, newline="", encoding="utf-8-sig") as f:
        sample = f.read(4096)
        f.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        return [row for row in csv.reader(f, dialect) if any(c.strip() for c in row)]


def _layout(rows: list[list[str]], aliases, required, openflights_cols):
    """Return (column mapping, data rows)."""
    if not rows:
        return {}, []
    header_map = _map_header(rows[0], aliases)
    if all(k in header_map for k in required):
        return header_map, rows[1:]
    # no usable header -> assume OpenFlights positional layout
    return openflights_cols, rows


def read_airports(path: str | Path) -> tuple[list[Airport], list[str]]:
    """Parse an airports file. Returns (airports, warnings)."""
    rows = _read_rows(Path(path))
    cols, data = _layout(rows, AIRPORT_ALIASES, ("iata", "latitude", "longitude"),
                         OPENFLIGHTS_AIRPORT_COLS)
    warnings: list[str] = []
    seen: dict[str, Airport] = {}

    def get(row, key):
        i = cols.get(key)
        return row[i] if i is not None and i < len(row) else None

    for n, row in enumerate(data, start=1):
        iata = (_clean(get(row, "iata")) or "").upper()
        lat, lon = _float(get(row, "latitude")), _float(get(row, "longitude"))
        if len(iata) != 3 or not iata.isalnum():
            continue  # airfields without an IATA code can't be route endpoints
        if lat is None or lon is None or not (-90 <= lat <= 90 and -180 <= lon <= 180):
            warnings.append(f"airports row {n}: {iata} has bad coordinates, skipped")
            continue
        if iata in seen:
            warnings.append(f"airports row {n}: duplicate IATA {iata}, kept first")
            continue
        seen[iata] = Airport(
            iata=iata,
            icao=(_clean(get(row, "icao")) or "").upper() or None,
            name=_clean(get(row, "name")) or iata,
            city=_clean(get(row, "city")),
            country=_clean(get(row, "country")),
            latitude=lat, longitude=lon,
            altitude_ft=_float(get(row, "altitude_ft")),
            timezone=_clean(get(row, "timezone")),
        )
    return list(seen.values()), warnings


def read_routes(path: str | Path, airports: Iterable[Airport]) -> tuple[list[AirRoute], list[str]]:
    """Parse a routes file, merge airlines per airport pair and compute distances.

    Routes whose endpoints are not in ``airports`` are dropped (with a warning
    count), so every relationship in the graph has valid coordinates.
    """
    by_code = {a.iata: a for a in airports}
    rows = _read_rows(Path(path))
    cols, data = _layout(rows, ROUTE_ALIASES, ("source", "dest"), OPENFLIGHTS_ROUTE_COLS)
    warnings: list[str] = []
    merged: dict[tuple[str, str], AirRoute] = {}
    unknown = 0

    def get(row, key):
        i = cols.get(key)
        return row[i] if i is not None and i < len(row) else None

    for row in data:
        src = (_clean(get(row, "source")) or "").upper()
        dst = (_clean(get(row, "dest")) or "").upper()
        if not src or not dst or src == dst:
            continue
        stops = _float(get(row, "stops"))
        if stops:  # only direct legs make sense as graph edges
            continue
        a, b = by_code.get(src), by_code.get(dst)
        if a is None or b is None:
            unknown += 1
            continue
        route = merged.get((src, dst))
        if route is None:
            dist = _float(get(row, "distance_km"))
            if dist is None or dist <= 0:
                dist = haversine_km(a.latitude, a.longitude, b.latitude, b.longitude)
            route = merged[(src, dst)] = AirRoute(src, dst, round(dist, 1))
        airline = (_clean(get(row, "airline")) or "").upper()
        if airline and airline not in route.airlines:
            route.airlines.append(airline)

    if unknown:
        warnings.append(f"{unknown} route rows reference airports not in the airports file, skipped")
    return list(merged.values()), warnings
