# csvtoneo4jairsea: air API

This project loads airport and air-route CSVs into Neo4j and serves them through two endpoints, `/api/airports` and `/api/air/route`.

## Setup (Windows, Anaconda Prompt or PowerShell)

```bat
cd csvtoneo4jairsea
python -m venv .venv && .venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env        &:: then set NEO4J_PASSWORD (and URI/database if not default)
```

Start your database in Neo4j Desktop first, then:

```bat
python load_air.py --dry-run                      &:: parse the CSVs and show warnings
python load_air.py                                &:: load data\airports.csv + data\air_routes.csv
python load_air.py my\airports.dat my\routes.dat --replace-routes
uvicorn app.api:app --reload                      &:: http://127.0.0.1:8000/docs
```

**Deployment without FastAPI:** `server.py` serves the page and the same API using only the standard library (plus the `neo4j` driver):

```bat
python server.py                        &:: http://127.0.0.1:8100/air_routing.html
python server.py --host 0.0.0.0         &:: reachable as http://your-server:8100
python server.py --backend csv          &:: no Neo4j, serve the CSV files
```

It handles `GET` routes in `do_GET`, `POST /api/air/routes` and `/api/air/reload` in `do_POST`, and CORS preflight in `do_OPTIONS`.

Open **http://127.0.0.1:8000/air_routing.html** for the route finder (`/` redirects there).

To run without Neo4j (for example during front-end work), set `AIRSEA_BACKEND=csv`. The API will then serve the CSV files directly.

## CSV formats

The loader accepts two layouts:

- **CSV with a header row.** Column names are matched loosely: `iata`/`code`, `lat`/`latitude`, `lon`/`lng`, `source`/`from`/`origin`, `dest`/`to`/`destination`, `airline`, and an optional `distance_km`. The separator can be `,`, `;`, a tab or `|`.
- **OpenFlights files** (`airports.dat`, `routes.dat`) with no header.

Some rows are dropped during loading:

- Airports without a 3-letter IATA code.
- Routes with stops, since only direct legs become edges.
- Routes to unknown airports.

When a route has no `distance_km`, the loader computes the great-circle distance. Routes for the same pair of airports are merged into one edge, and that edge lists every airline that flies it.

## Graph model

```
(:Airport {iata, icao, name, city, country, latitude, longitude, altitude_ft, timezone, location})
(:Airport)-[:AIR_ROUTE {distance_km, airlines}]->(:Airport)
```

`iata` has a uniqueness constraint. `icao`, `country` and `location` (a point) are indexed.

## Endpoints

| Method | Path | Query |
|---|---|---|
| GET | `/api/health` | |
| GET | `/api/airports` | `search` (exact IATA/ICAO, or a substring of the name or city), `country`, `limit` (≤500, default 50), `offset` |
| GET | `/api/airports/{code}` | IATA or ICAO. Also returns `departures` and `arrivals` counts |
| GET | `/api/airports/{code}/routes` | direct departures, nearest first |
| GET | `/api/air/route` | `from`, `to` (IATA or ICAO), `optimize=distance\|stops`, `max_stops` (0–4, default 2), `avoid=DXB,DOH` |
| GET | `/air_routing.html` | the route-finder page |
| POST | `/api/air/routes` | JSON body `{"from", "to", "k" (1–6, default 3), "optimize", "max_stops", "avoid": [..]}`. Returns up to `k` distinct corridors, best first |
| POST | `/api/air/reload` | drops the cached route graph. Call it after re-running the loader |

Example: `GET /api/air/route?from=NRT&to=MAD&max_stops=4`

```json
{
  "from": {"iata": "NRT", "...": "..."}, "to": {"iata": "MAD", "...": "..."},
  "optimize": "distance", "max_stops": 4, "avoid": [],
  "direct_distance_km": 10766.1, "found": true,
  "stops": 4, "connections": ["HKG", "SIN", "IST", "LHR"],
  "total_distance_km": 17942.1, "detour_ratio": 1.667,
  "legs": [{"from": {}, "to": {}, "distance_km": 2950.3, "airlines": ["CX"]}],
  "path": [[140.3864, 35.7647], [113.9147, 22.3089]]
}
```

- `path` is a list of `[lon, lat]` pairs. You can drop it straight into a GeoJSON LineString or a map polyline.
- An unknown airport code returns **404**.
- If no route exists within `max_stops`, the response is **200** with `"found": false` and a `message`.

## Distinct corridors

A corridor is a route from origin to destination. Corridors are *distinct* when they share no connecting airport:

1. Corridor 1 is the ordinary best route.
2. Each later corridor is the best route that avoids every hub used by the corridors before it.
3. A non-stop flight counts as one corridor; after it, the rest must connect somewhere.

So the list gives genuinely different ways to make the trip, not small variations of one, and they come back best first. If fewer than `k` exist within `max_stops`, the response says so in `message`.

On the page, **Find distinct corridors** (`id="find"`) POSTs to `/api/air/routes` and lists the corridors. The selected one is drawn solid and the others dashed, each in its own colour. Click a corridor to see its legs. Changing the stops or optimise setting reruns whichever search you used last.

## How routing works

Neo4j's `shortestPath` only counts hops, and weighted search needs the APOC or GDS plugins. So the API reads the `AIR_ROUTE` edges once and keeps them cached for `GRAPH_CACHE_SECONDS` (300 by default). It then runs a hop-limited Dijkstra search in Python:

- `optimize=distance` finds the fewest kilometres.
- `optimize=stops` finds the fewest legs, and breaks ties on kilometres.

This works on a plain Neo4j install. With the full OpenFlights data (about 67k routes), a search takes a few milliseconds. The search code is in `app/routing.py` and doesn't depend on air data, so sea routes can reuse it.

## Route-finder page

`static/air_routing.html` is a single page with a search form, a route summary, a list of legs and a map. The map centres on the route and draws great-circle lines, plus faint lines for direct departures from the origin.

- **Deployment:** if the API serves the page (the usual setup, e.g. `http://your-server:8100/air_routing.html`), leave `API_BASE` empty at the top of the page's script. If the page is hosted somewhere else, set `API_BASE` to the API's address, e.g. `"http://your-server:8100"`, and allow that site in `CORS_ORIGINS`.
- With `API_BASE` empty, the page tries the server it came from, then `http://127.0.0.1:8100`, `http://127.0.0.1:8000` and `http://localhost:8000`, and uses the first that answers `/api/health`.
- In live mode the page reads airports from `GET /api/airports` (`do_GET` in `server.py`). It loads the whole list once, 500 at a time, for the map, and asks again with `?search=` for suggestions as you type. The response is `{"total", "limit", "offset", "items": [airport, ...]}`; the page also accepts a bare list.
- If none answers, it falls back to the sample data embedded in the page. The badge then reads *Sample data*, and hovering over it shows why (API not running, browser blocked the call, or the API is up but Neo4j isn't).
- Coastlines come from the `world-atlas` package on jsDelivr, so the map needs internet access to show them.

Edit `static/air_routing.template.html`, then run `python tools/build_page.py` to re-embed the sample data.

## Tests

```bat
python -m pytest tests -q
```

The tests cover CSV parsing (headered, OpenFlights and semicolon files) and compare the route search against brute force for every airport pair and stop limit. They also cover the response builder and airport search.
