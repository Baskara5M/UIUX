"""Builds API responses. Kept free of any web framework so FastAPI (app/api.py),
the stdlib server (server.py) and the tests all share it."""
from __future__ import annotations

from .geo import haversine_km
from .repo import AirRepository
from .routing import Edge, Optimize

MAX_CORRIDORS = 6


class AirportNotFound(LookupError):
    def __init__(self, code: str):
        super().__init__(f"Unknown airport code '{code}'")
        self.code = code


def resolve_iata(repo: AirRepository, code: str) -> str:
    """Accept an IATA or ICAO code; return the IATA code."""
    airport = repo.get_airport(code.strip().upper())
    if airport is None:
        raise AirportNotFound(code)
    return airport["iata"]


def _direct_km(a: dict, b: dict) -> float:
    return round(haversine_km(a["latitude"], a["longitude"], b["latitude"], b["longitude"]), 1)


def _path_details(path: list[Edge], airports: dict[str, dict], direct_km: float) -> dict:
    """Stops, legs, totals and map coordinates for one found path."""
    legs = [{
        "from": airports[e.source],
        "to": airports[e.dest],
        "distance_km": e.distance_km,
        "airlines": list(e.airlines),
    } for e in path]
    total = round(sum(e.distance_km for e in path), 1)
    first = legs[0]["from"]
    return {
        "stops": len(path) - 1,
        "connections": [e.dest for e in path[:-1]],
        "total_distance_km": total,
        "detour_ratio": round(total / direct_km, 3) if direct_km else None,
        "legs": legs,
        # [lon, lat] pairs, ready for a GeoJSON LineString / map polyline
        "path": [[first["longitude"], first["latitude"]]] +
                [[leg["to"]["longitude"], leg["to"]["latitude"]] for leg in legs],
    }


def air_route(repo: AirRepository, origin: str, dest: str, optimize: Optimize = "distance",
              max_stops: int = 3, avoid: list[str] | None = None) -> dict:
    src = resolve_iata(repo, origin)
    dst = resolve_iata(repo, dest)
    avoid_codes = frozenset(resolve_iata(repo, c) for c in (avoid or []) if c.strip())

    graph = repo.route_graph()
    path = graph.shortest(src, dst, optimize=optimize, max_stops=max_stops, avoid=avoid_codes)

    codes = [src, dst] + ([e.dest for e in path] if path else [])
    airports = repo.get_airports(sorted(set(codes)))
    a, b = airports[src], airports[dst]
    result = {
        "from": a,
        "to": b,
        "optimize": optimize,
        "max_stops": max_stops,
        "avoid": sorted(avoid_codes),
        "direct_distance_km": _direct_km(a, b),
        "found": path is not None,
    }
    if path is None:
        result["message"] = (f"No air route from {src} to {dst} with at most "
                             f"{max_stops} stop(s)" + (" avoiding " + ", ".join(sorted(avoid_codes))
                                                       if avoid_codes else ""))
        return result
    result.update(_path_details(path, airports, result["direct_distance_km"]))
    return result


def air_corridors(repo: AirRepository, origin: str, dest: str, k: int = 3,
                  optimize: Optimize = "distance", max_stops: int = 3,
                  avoid: list[str] | None = None) -> dict:
    """Up to ``k`` distinct corridors from ``origin`` to ``dest``.

    Corridors share no connecting airport: each one is the best route that
    avoids every hub used by the corridors found before it. A non-stop flight
    counts as one corridor; later corridors must then connect somewhere.
    Corridors come back best first.
    """
    if not 1 <= k <= MAX_CORRIDORS:
        raise ValueError(f"k must be between 1 and {MAX_CORRIDORS}")
    src = resolve_iata(repo, origin)
    dst = resolve_iata(repo, dest)
    if src == dst:
        raise ValueError("'from' and 'to' must differ")
    user_avoid = frozenset(resolve_iata(repo, c) for c in (avoid or []) if c.strip())

    graph = repo.route_graph()
    used_hubs: set[str] = set(user_avoid)
    banned: set[tuple[str, str]] = set()
    paths: list[list[Edge]] = []
    while len(paths) < k:
        path = graph.shortest(src, dst, optimize=optimize, max_stops=max_stops,
                              avoid=frozenset(used_hubs), banned_edges=frozenset(banned))
        if not path:
            break
        paths.append(path)
        hubs = [e.dest for e in path[:-1]]
        if hubs:
            used_hubs.update(hubs)
        else:
            banned.add((src, dst))  # the non-stop corridor is taken

    codes = {src, dst} | {e.dest for p in paths for e in p}
    airports = repo.get_airports(sorted(codes))
    a, b = airports[src], airports[dst]
    direct = _direct_km(a, b)
    corridors = []
    for rank, path in enumerate(paths, 1):
        c = {"rank": rank, **_path_details(path, airports, direct)}
        c["via"] = c["connections"] or ["non-stop"]
        corridors.append(c)

    result = {
        "from": a,
        "to": b,
        "k": k,
        "optimize": optimize,
        "max_stops": max_stops,
        "avoid": sorted(user_avoid),
        "direct_distance_km": direct,
        "count": len(corridors),
        "corridors": corridors,
    }
    if len(corridors) < k:
        result["message"] = (
            f"Found {len(corridors)} of {k} distinct corridor(s) from {src} to {dst} "
            f"with at most {max_stops} stop(s). Allow more stops to find more.")
    return result
