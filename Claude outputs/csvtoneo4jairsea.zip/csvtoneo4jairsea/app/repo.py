"""Data access. ``Neo4jRepo`` is the real backend; ``CsvRepo`` serves the same
data straight from the CSV files (handy for front-end work without Neo4j)."""
from __future__ import annotations

import threading
import time
from typing import Protocol

from .csv_io import read_airports, read_routes
from .routing import Edge, RouteGraph

AIRPORT_FIELDS = ("iata", "icao", "name", "city", "country",
                  "latitude", "longitude", "altitude_ft", "timezone")
# explicit projection: keeps the spatial `location` property out of JSON
AIRPORT_PROJ = "a{" + ", ".join("." + f for f in AIRPORT_FIELDS) + "}"


class AirRepository(Protocol):
    def list_airports(self, search: str | None, country: str | None,
                      limit: int, offset: int) -> tuple[int, list[dict]]: ...
    def get_airport(self, code: str) -> dict | None: ...
    def get_airports(self, iata_codes: list[str]) -> dict[str, dict]: ...
    def departures(self, iata: str) -> list[dict]: ...
    def route_graph(self) -> RouteGraph: ...
    def close(self) -> None: ...


class _GraphCache:
    def __init__(self, ttl: int, loader):
        self.ttl, self.loader = ttl, loader
        self._graph: RouteGraph | None = None
        self._at = 0.0
        self._lock = threading.Lock()

    def get(self) -> RouteGraph:
        with self._lock:
            if self._graph is None or time.monotonic() - self._at > self.ttl:
                self._graph = RouteGraph(self.loader())
                self._at = time.monotonic()
            return self._graph

    def clear(self) -> None:
        with self._lock:
            self._graph = None


# --------------------------------------------------------------------- Neo4j
class Neo4jRepo:
    def __init__(self, uri: str, user: str, password: str, database: str,
                 cache_seconds: int = 300):
        from neo4j import GraphDatabase  # imported here so CsvRepo works without it

        # fail fast when Neo4j is down so /api/health returns 503 instead of hanging
        self.driver = GraphDatabase.driver(uri, auth=(user, password),
                                           connection_timeout=5,
                                           connection_acquisition_timeout=10)
        self.database = database
        self.cache = _GraphCache(cache_seconds, self._load_edges)

    def _run(self, query: str, **params) -> list[dict]:
        records, _, _ = self.driver.execute_query(
            query, params, database_=self.database, routing_="r")
        return [r.data() for r in records]

    def list_airports(self, search, country, limit, offset):
        rows = self._run(
            f"""
            MATCH (a:Airport)
            WHERE ($q IS NULL
                   OR a.iata = toUpper($q) OR a.icao = toUpper($q)
                   OR toLower(a.name) CONTAINS $q
                   OR toLower(coalesce(a.city, '')) CONTAINS $q)
              AND ($country IS NULL OR toLower(a.country) = $country)
            WITH a ORDER BY
              CASE WHEN $q IS NOT NULL AND (a.iata = toUpper($q) OR a.icao = toUpper($q))
                   THEN 0 ELSE 1 END,
              a.name
            WITH collect({AIRPORT_PROJ}) AS rows
            RETURN size(rows) AS total, rows[$offset..$offset + $limit] AS items
            """,
            q=search.lower() if search else None,
            country=country.lower() if country else None,
            offset=offset, limit=limit,
        )
        return rows[0]["total"], rows[0]["items"]

    def get_airport(self, code):
        rows = self._run(
            f"""
            MATCH (a:Airport) WHERE a.iata = $code OR a.icao = $code
            WITH a ORDER BY CASE WHEN a.iata = $code THEN 0 ELSE 1 END LIMIT 1
            RETURN {AIRPORT_PROJ} AS airport,
                   COUNT {{ (a)-[:AIR_ROUTE]->() }} AS departures,
                   COUNT {{ ()-[:AIR_ROUTE]->(a) }} AS arrivals
            """,
            code=code.upper(),
        )
        if not rows:
            return None
        return {**rows[0]["airport"], "departures": rows[0]["departures"],
                "arrivals": rows[0]["arrivals"]}

    def get_airports(self, iata_codes):
        rows = self._run(
            f"MATCH (a:Airport) WHERE a.iata IN $codes RETURN {AIRPORT_PROJ} AS airport",
            codes=list(iata_codes),
        )
        return {r["airport"]["iata"]: r["airport"] for r in rows}

    def departures(self, iata):
        return self._run(
            f"""
            MATCH (:Airport {{iata: $code}})-[r:AIR_ROUTE]->(a:Airport)
            RETURN {AIRPORT_PROJ} AS airport, r.distance_km AS distance_km,
                   r.airlines AS airlines
            ORDER BY distance_km
            """,
            code=iata.upper(),
        )

    def _load_edges(self) -> list[Edge]:
        rows = self._run(
            """
            MATCH (s:Airport)-[r:AIR_ROUTE]->(d:Airport)
            RETURN s.iata AS s, d.iata AS d, r.distance_km AS km, r.airlines AS airlines
            """
        )
        return [Edge(r["s"], r["d"], float(r["km"] or 0), tuple(r["airlines"] or ()))
                for r in rows]

    def route_graph(self):
        return self.cache.get()

    def ping(self) -> None:
        self.driver.verify_connectivity()

    def close(self):
        self.driver.close()


# ----------------------------------------------------------------------- CSV
class CsvRepo:
    def __init__(self, airports_csv: str, routes_csv: str):
        airports, _ = read_airports(airports_csv)
        routes, _ = read_routes(routes_csv, airports)
        self.airports = {a.iata: a.to_dict() for a in airports}
        self.by_icao = {a.icao: a.iata for a in airports if a.icao}
        self.routes = routes
        self.graph = RouteGraph(Edge(r.source, r.dest, r.distance_km, tuple(r.airlines))
                                for r in routes)

    def list_airports(self, search, country, limit, offset):
        q = search.lower() if search else None
        c = country.lower() if country else None
        hits = []
        for a in self.airports.values():
            if c and (a["country"] or "").lower() != c:
                continue
            exact = bool(q) and q.upper() in (a["iata"], a["icao"])
            if q and not (exact or q in a["name"].lower() or q in (a["city"] or "").lower()):
                continue
            hits.append((0 if exact else 1, a["name"], a))
        hits.sort(key=lambda t: (t[0], t[1]))
        return len(hits), [h[2] for h in hits[offset:offset + limit]]

    def get_airport(self, code):
        code = code.upper()
        iata = code if code in self.airports else self.by_icao.get(code)
        if iata is None:
            return None
        return {**self.airports[iata],
                "departures": len(self.graph.adj.get(iata, ())),
                "arrivals": sum(1 for r in self.routes if r.dest == iata)}

    def get_airports(self, iata_codes):
        return {c: self.airports[c] for c in iata_codes if c in self.airports}

    def departures(self, iata):
        out = [{"airport": self.airports[e.dest], "distance_km": e.distance_km,
                "airlines": list(e.airlines)} for e in self.graph.adj.get(iata.upper(), ())]
        return sorted(out, key=lambda r: r["distance_km"])

    def route_graph(self):
        return self.graph

    def ping(self) -> None:
        pass

    def close(self):
        pass
