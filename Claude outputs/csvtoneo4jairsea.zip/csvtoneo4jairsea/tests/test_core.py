"""Tests for parsing, route search and the response builder (no Neo4j needed).

    python -m pytest tests -q      (or: python tests/test_core.py)
"""
import itertools
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.csv_io import read_airports, read_routes  # noqa: E402
from app.geo import haversine_km  # noqa: E402
from app.repo import CsvRepo  # noqa: E402
from app.routing import Edge, RouteGraph  # noqa: E402
from app.service import AirportNotFound, air_corridors, air_route  # noqa: E402

DATA = ROOT / "data"


def repo():
    return CsvRepo(str(DATA / "airports.csv"), str(DATA / "air_routes.csv"))


# ------------------------------------------------------------------ parsing
def test_haversine_jfk_lhr():
    d = haversine_km(40.6398, -73.7789, 51.4706, -0.4619)
    assert 5530 < d < 5560


def test_headered_csv_parsing():
    airports, warnings = read_airports(DATA / "airports.csv")
    assert len(airports) == 21 and not warnings
    routes, rw = read_routes(DATA / "air_routes.csv", airports)
    pairs = {(r.source, r.dest): r for r in routes}
    assert sorted(pairs[("JFK", "LAX")].airlines) == ["AA", "DL"]   # merged per pair
    assert ("JFK", "ZZZ") not in pairs and rw[0].startswith("1 route rows")
    assert len(rw) == 1


def test_openflights_layout():
    with tempfile.TemporaryDirectory() as d:
        ap = Path(d) / "airports.dat"
        ap.write_text(
            '1,"Goroka Airport","Goroka","Papua New Guinea","GKA","AYGA",-6.08,145.39,5282,10,"U","Pacific/Port_Moresby","airport","OurAirports"\n'
            '2,"Madang Airport","Madang","Papua New Guinea","MAG","AYMD",-5.20,145.78,20,10,"U","Pacific/Port_Moresby","airport","OurAirports"\n'
            '3,"No Code Strip","X","Y",\\N,"ZZZZ",1.0,1.0,0,0,"U",\\N,"airport","OurAirports"\n',
            encoding="utf-8")
        rt = Path(d) / "routes.dat"
        rt.write_text("CG,1308,GKA,1,MAG,2,,0,DH8\nCG,1308,MAG,2,GKA,1,,0,DH8\nPX,328,GKA,1,MAG,2,Y,0,DH8\n",
                      encoding="utf-8")
        airports, _ = read_airports(ap)
        assert [a.iata for a in airports] == ["GKA", "MAG"]
        assert airports[0].timezone == "Pacific/Port_Moresby"
        routes, _ = read_routes(rt, airports)
        r = {(x.source, x.dest): x for x in routes}
        assert sorted(r[("GKA", "MAG")].airlines) == ["CG", "PX"]
        assert r[("GKA", "MAG")].distance_km > 0


def test_semicolon_and_alias_headers():
    with tempfile.TemporaryDirectory() as d:
        ap = Path(d) / "a.csv"
        ap.write_text("Code;Airport Name;Lat;Lng\nAAA;A;0;0\nBBB;B;0;1\n", encoding="utf-8")
        rt = Path(d) / "r.csv"
        rt.write_text("origin;destination;distance\nAAA;BBB;999\n", encoding="utf-8")
        airports, _ = read_airports(ap)
        routes, _ = read_routes(rt, airports)
        assert [a.name for a in airports] == ["A", "B"]
        assert routes[0].distance_km == 999


# ------------------------------------------------------------------ routing
def brute_force(graph, src, dst, max_stops, key):
    """Enumerate all simple paths up to max_stops for comparison."""
    best = None
    stack = [(src, [], {src})]
    while stack:
        node, path, seen = stack.pop()
        if node == dst and path:
            k = key(path)
            if best is None or k < best:
                best = k
            continue
        if len(path) == max_stops + 1:
            continue
        for e in graph.adj.get(node, ()):
            if e.dest not in seen:
                stack.append((e.dest, path + [e], seen | {e.dest}))
    return best


def test_dijkstra_matches_brute_force():
    g = repo().route_graph()
    codes = sorted({e.source for edges in g.adj.values() for e in edges})
    by_km = lambda p: round(sum(e.distance_km for e in p), 6)  # noqa: E731
    by_stops = lambda p: (len(p), round(sum(e.distance_km for e in p), 6))  # noqa: E731
    checked = 0
    for s, t in itertools.permutations(codes, 2):
        for ms in (0, 1, 2, 3):
            exp = brute_force(g, s, t, ms, by_km)
            got = g.shortest(s, t, "distance", ms)
            assert (got is None) == (exp is None), (s, t, ms)
            if got is not None:
                assert by_km(got) == exp, (s, t, ms)
                assert len(got) <= ms + 1
                assert all(a.dest == b.source for a, b in zip(got, got[1:]))
            exp2 = brute_force(g, s, t, ms, by_stops)
            got2 = g.shortest(s, t, "stops", ms)
            assert (got2 is None) == (exp2 is None)
            if got2 is not None:
                assert by_stops(got2) == exp2, (s, t, ms)
            checked += 1
    assert checked > 1000


def test_hop_limit_beats_greedy():
    # cheapest path A->D is 3 legs; with max 1 stop the 2-leg path must be found
    g = RouteGraph([Edge("A", "B", 1), Edge("B", "C", 1), Edge("C", "D", 1),
                    Edge("A", "X", 5), Edge("X", "D", 5), Edge("B", "D", 50)])
    assert [e.dest for e in g.shortest("A", "D", "distance", 2)] == ["B", "C", "D"]
    assert [e.dest for e in g.shortest("A", "D", "distance", 1)] == ["X", "D"]
    assert g.shortest("A", "D", "distance", 0) is None
    assert [e.dest for e in g.shortest("A", "D", "distance", 2, frozenset({"C"}))] == ["X", "D"]


# ------------------------------------------------------------------ service
def test_air_route_response():
    r = repo()
    res = air_route(r, "SYD", "GRU", "distance", 3)
    assert res["found"]
    assert res["legs"][0]["from"]["iata"] == "SYD"
    assert res["legs"][-1]["to"]["iata"] == "GRU"
    assert res["stops"] == len(res["legs"]) - 1 == len(res["connections"])
    assert len(res["path"]) == len(res["legs"]) + 1
    assert res["total_distance_km"] >= res["direct_distance_km"]

    # ICAO input works, direct route
    res = air_route(r, "KJFK", "egll", "stops", 0)
    assert res["found"] and res["stops"] == 0 and sorted(res["legs"][0]["airlines"]) == ["AA", "BA"]

    # unreachable within limit
    res = air_route(r, "SYD", "GRU", "distance", 0)
    assert not res["found"] and "No air route" in res["message"]

    try:
        air_route(r, "JFK", "QQQ")
    except AirportNotFound as e:
        assert e.code == "QQQ"
    else:
        raise AssertionError("expected AirportNotFound")


def test_corridors_are_distinct_and_ordered():
    r = repo()
    codes = sorted(r.airports)
    checked = 0
    for s_, t in itertools.permutations(codes, 2):
        for opt in ("distance", "stops"):
            res = air_corridors(r, s_, t, k=4, optimize=opt, max_stops=3)
            cs = res["corridors"]
            best = air_route(r, s_, t, opt, 3)
            assert (len(cs) > 0) == best["found"]
            if not cs:
                continue
            # corridor 1 is the ordinary best route
            assert cs[0]["total_distance_km"] == best["total_distance_km"]
            # no connecting airport is shared between corridors
            hubs = [h for c in cs for h in c["connections"]]
            assert len(hubs) == len(set(hubs)), (s_, t, hubs)
            # at most one non-stop corridor
            assert sum(1 for c in cs if c["stops"] == 0) <= 1
            # best first
            key = (lambda c: c["total_distance_km"]) if opt == "distance" else \
                  (lambda c: (c["stops"], c["total_distance_km"]))
            assert [key(c) for c in cs] == sorted(key(c) for c in cs)
            for c in cs:
                assert c["legs"][0]["from"]["iata"] == s_ and c["legs"][-1]["to"]["iata"] == t
                assert c["stops"] <= 3
            checked += 1
    assert checked > 300


def test_corridor_example_and_limits():
    r = repo()
    res = air_corridors(r, "JFK", "LHR", k=3, max_stops=2)
    assert res["count"] == 3
    assert res["corridors"][0]["via"] == ["non-stop"]
    assert res["corridors"][1]["stops"] >= 1
    for bad in (0, 7):
        try:
            air_corridors(r, "JFK", "LHR", k=bad)
        except ValueError:
            pass
        else:
            raise AssertionError("k out of range accepted")
    few = air_corridors(r, "SYD", "GRU", k=5, max_stops=3)
    assert few["count"] < 5 and "Allow more stops" in few["message"]


def test_airport_listing():
    r = repo()
    total, items = r.list_airports("lhr", None, 10, 0)
    assert items[0]["iata"] == "LHR"
    total, items = r.list_airports("international", "united states", 2, 0)
    assert total == 5 and len(items) == 2
    total, items = r.list_airports(None, None, 50, 20)
    assert total == 21 and len(items) == 1
    a = r.get_airport("lhr")
    assert a["departures"] > 0 and a["arrivals"] > 0
    assert r.get_airport("NOPE") is None


if __name__ == "__main__":
    fns = [v for k, v in dict(globals()).items() if k.startswith("test_")]
    for f in fns:
        f()
        print("ok", f.__name__)
    print(f"{len(fns)} passed")
