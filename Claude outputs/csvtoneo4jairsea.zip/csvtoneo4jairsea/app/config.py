"""Settings, read from environment variables (or a .env file next to the project)."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv() -> None:
    env = ROOT / ".env"
    if not env.exists():
        return
    for line in env.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.split(" #", 1)[0]  # allow trailing comments
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_dotenv()


@dataclass(frozen=True)
class Settings:
    backend: str = os.getenv("AIRSEA_BACKEND", "neo4j")  # "neo4j" or "csv"
    neo4j_uri: str = os.getenv("NEO4J_URI", "neo4j://localhost:7687")
    neo4j_user: str = os.getenv("NEO4J_USER", "neo4j")
    neo4j_password: str = os.getenv("NEO4J_PASSWORD", "")
    neo4j_database: str = os.getenv("NEO4J_DATABASE", "neo4j")
    airports_csv: str = os.getenv("AIRPORTS_CSV", str(ROOT / "data" / "airports.csv"))
    air_routes_csv: str = os.getenv("AIR_ROUTES_CSV", str(ROOT / "data" / "air_routes.csv"))
    graph_cache_seconds: int = int(os.getenv("GRAPH_CACHE_SECONDS", "300"))
    max_stops_limit: int = int(os.getenv("MAX_STOPS_LIMIT", "4"))
    cors_origins: str = os.getenv("CORS_ORIGINS", "*")


settings = Settings()
