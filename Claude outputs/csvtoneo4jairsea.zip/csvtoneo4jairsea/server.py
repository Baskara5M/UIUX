"""Standalone HTTP server for deployment: serves air_routing.html and the API
using only the Python standard library (plus the neo4j driver).

    python server.py                          # http://127.0.0.1:8100
    python server.py --host 0.0.0.0           # reachable from other machines
    python server.py --port 9000 --backend csv

GET  /  and  /air_routing.html          the route-finder page
GET  /api/health
GET  /api/airports                      ?search=&country=&limit=&offset=
GET  /api/airports/{code}
GET  /api/airports/{code}/routes
GET  /api/air/route                     ?from=&to=&optimize=&max_stops=&avoid=
POST /api/air/routes                    JSON {"from","to","k","optimize","max_stops","avoid"}
POST /api/air/reload                    drop the cached route graph

Settings (Neo4j address, password, CORS) come from .env, as for app/api.py.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import traceback
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from app.config import ROOT, settings
from app.repo import CsvRepo, Neo4jRepo
from app.service import MAX_CORRIDORS, AirportNotFound, air_corridors, air_route, resolve_iata

PAGE = ROOT / "static" / "air_routing.html"
MAX_BODY = 64 * 1024
CODE_RE = re.compile(r"^[A-Za-z0-9]{3,4}$")


class ApiError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status, self.detail = status, detail


# ------------------------------------------------------------- validation
def _code(value, name: str) -> str:
    if not isinstance(value, str) or not CODE_RE.match(value.strip()):
        raise ApiError(422, f"'{name}' must be a 3-letter IATA or 4-letter ICAO code")
    return value.strip()


def _int(value, name: str, lo: int, hi: int, default: int) -> int:
    if value is None or value == "":
        return default
    try:
        n = int(value)
    except (TypeError, ValueError):
        raise ApiError(422, f"'{name}' must be a whole number") from None
    if not lo <= n <= hi:
        raise ApiError(422, f"'{name}' must be between {lo} and {hi}")
    return n


def _optimize(value) -> str:
    value = value or "distance"
    if value not in ("distance", "stops"):
        raise ApiError(422, "'optimize' must be 'distance' or 'stops'")
    return value


def _avoid(value) -> list[str]:
    if not value:
        return []
    items = value.split(",") if isinstance(value, str) else value
    if not isinstance(items, list):
        raise ApiError(422, "'avoid' must be a list of airport codes or a comma-separated string")
    return [_code(c, "avoid") for c in items if str(c).strip()]


# ---------------------------------------------------------------- handler
class Handler(BaseHTTPRequestHandler):
    server_version = "airsea/0.2"
    repo = None      # set in main()
    backend = "neo4j"

    # --- plumbing
    def _cors(self):
        allowed = [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
        origin = self.headers.get("Origin")
        if "*" in allowed:
            self.send_header("Access-Control-Allow-Origin", "*")
        elif origin and origin in allowed:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")

    def _send(self, status: int, payload=None, body: bytes | None = None,
              ctype: str = "application/json; charset=utf-8"):
        if body is None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json_body(self) -> dict:
        ctype = self.headers.get("Content-Type", "")
        if "application/json" not in ctype:
            raise ApiError(415, "Send the request body as JSON (Content-Type: application/json)")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(400, "Invalid Content-Length") from None
        if length > MAX_BODY:
            raise ApiError(413, "Request body too large")
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw or b"{}")
        except json.JSONDecodeError as e:
            raise ApiError(400, f"Body is not valid JSON: {e.msg}") from None
        if not isinstance(data, dict):
            raise ApiError(400, "Body must be a JSON object")
        return data

    def _dispatch(self, fn):
        try:
            fn()
        except ApiError as e:
            self._send(e.status, {"detail": e.detail})
        except AirportNotFound as e:
            self._send(404, {"detail": str(e)})
        except ValueError as e:
            self._send(422, {"detail": str(e)})
        except BrokenPipeError:
            pass
        except Exception as e:  # keep the server up; report the cause
            traceback.print_exc()
            self._send(500, {"detail": f"{type(e).__name__}: {e}"})

    # --- HTTP methods
    def do_OPTIONS(self):
        # CORS preflight: browsers send this before a cross-site JSON POST
        self.send_response(HTTPStatus.NO_CONTENT)
        self._cors()
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        self._dispatch(self._get)

    def do_HEAD(self):
        self._dispatch(self._get)

    def do_POST(self):
        self._dispatch(self._post)

    # --- routes
    def _get(self):
        url = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        path = url.path.rstrip("/") or "/"
        repo = self.repo

        if path in ("/", "/air_routing.html"):
            if not PAGE.exists():
                raise ApiError(404, "static/air_routing.html is missing. Run: python tools/build_page.py")
            return self._send(200, body=PAGE.read_bytes(), ctype="text/html; charset=utf-8")

        if path == "/api/health":
            try:
                repo.ping()
            except Exception as e:
                raise ApiError(503, f"database unavailable: {e}") from None
            return self._send(200, {"status": "ok", "backend": self.backend})

        if path == "/api/airports":
            search = (q.get("search") or "").strip() or None
            if search and len(search) > 100:
                raise ApiError(422, "'search' is too long")
            limit = _int(q.get("limit"), "limit", 1, 500, 50)
            offset = _int(q.get("offset"), "offset", 0, 10**6, 0)
            total, items = repo.list_airports(search, (q.get("country") or "").strip() or None, limit, offset)
            return self._send(200, {"total": total, "limit": limit, "offset": offset, "items": items})

        m = re.fullmatch(r"/api/airports/([^/]+)(/routes)?", path)
        if m:
            code = _code(m.group(1), "code")
            if m.group(2):
                iata = resolve_iata(repo, code)
                items = repo.departures(iata)
                return self._send(200, {"from": iata, "total": len(items), "items": items})
            airport = repo.get_airport(code)
            if airport is None:
                raise AirportNotFound(code)
            return self._send(200, airport)

        if path == "/api/air/route":
            origin, dest = _code(q.get("from"), "from"), _code(q.get("to"), "to")
            if origin.upper() == dest.upper():
                raise ApiError(400, "'from' and 'to' must differ")
            return self._send(200, air_route(
                repo, origin, dest, optimize=_optimize(q.get("optimize")),
                max_stops=_int(q.get("max_stops"), "max_stops", 0, settings.max_stops_limit, 2),
                avoid=_avoid(q.get("avoid"))))

        if path in ("/api/air/routes", "/api/air/reload"):
            raise ApiError(405, f"Use POST for {path}")
        raise ApiError(404, "Not Found")

    def _post(self):
        path = urlparse(self.path).path.rstrip("/")
        repo = self.repo

        if path == "/api/air/routes":
            body = self._json_body()
            origin, dest = _code(body.get("from"), "from"), _code(body.get("to"), "to")
            if origin.upper() == dest.upper():
                raise ApiError(400, "'from' and 'to' must differ")
            return self._send(200, air_corridors(
                repo, origin, dest,
                k=_int(body.get("k"), "k", 1, MAX_CORRIDORS, 3),
                optimize=_optimize(body.get("optimize")),
                max_stops=_int(body.get("max_stops"), "max_stops", 0, settings.max_stops_limit, 3),
                avoid=_avoid(body.get("avoid"))))

        if path == "/api/air/reload":
            cache = getattr(repo, "cache", None)
            if cache is not None:
                cache.clear()
            graph = repo.route_graph()
            return self._send(200, {"airports_with_departures": len(graph.adj), "routes": graph.edge_count})

        raise ApiError(404, "Not Found")


def make_repo(backend: str):
    if backend == "csv":
        return CsvRepo(settings.airports_csv, settings.air_routes_csv)
    return Neo4jRepo(settings.neo4j_uri, settings.neo4j_user, settings.neo4j_password,
                     settings.neo4j_database, settings.graph_cache_seconds)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Serve air_routing.html and the air API.")
    p.add_argument("--host", default="127.0.0.1", help="use 0.0.0.0 to accept other machines")
    p.add_argument("--port", type=int, default=8100)
    p.add_argument("--backend", choices=["neo4j", "csv"], default=settings.backend)
    args = p.parse_args(argv)

    Handler.repo = make_repo(args.backend)
    Handler.backend = args.backend
    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    shown = "127.0.0.1" if args.host == "0.0.0.0" else args.host
    print(f"air routing on http://{shown}:{args.port}/air_routing.html  (backend: {args.backend})")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        Handler.repo.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
